package com.app.uccplanner.Models;

import android.content.Context;

public class EventModels {
    String day, month, title, place, count, url;

    public String getDay() {
        return day;
    }

    public String getMonth() {
        return month;
    }

    public String getTitle() {
        return title;
    }

    public String getPlace() {
        return place;
    }

    public String getCount() {
        return count;
    }

    public String getUrl() {
        return url;
    }
}
